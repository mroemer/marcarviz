Credits
=======

“inchlib_clust” is written and maintained by Ctibor Skuta.